(@p4programIR.«% ';'» ([(@declarationIR.«% CONST % % % ';'» (@annotationList._EMPTY) (@typeIR.BOOL) "tmp" (@constantInitializerIR.«'=' _VALUE %» (@value._B true)))] : (_root_.List declarationIR)))
