(@p4programIR.«% ';'» ([] : (_root_.List declarationIR)))
